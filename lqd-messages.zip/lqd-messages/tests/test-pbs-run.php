<?php

class GCSS_Play_Button_Run_Test extends WP_UnitTestCase {

	function test_class_exists() {
		$this->assertTrue( class_exists( 'GCSS_Play_Button_Run') );
	}
}
