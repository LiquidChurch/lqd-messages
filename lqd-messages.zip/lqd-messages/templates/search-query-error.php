<div class="gc-search-results-error <?php $this->output( 'wrap_classes', 'esc_attr' ); ?>">
	<h2 class="gc-search-results-error-title"><?php _e( 'For performance reasons, please enter at least 3 characters in your search.', 'gc-sermons' ) ?></h2>
</div>
