# GC Sermons Assets #
http://dsgnwrks.pro
Copyright (c) 2016 jtsternberg
Licensed under the GPLv2 license.

Assets such as styles, javascript, and images.
